"""
import logging
logger = logging.getLogger(__name__)
AI Interview Preparation Service
Uses Claude API to prepare candidates for interviews
"""
import os
from typing import Dict, List, Optional, Any
from anthropic import Anthropic
import json

class AIInterviewService:
    def __init__(self):
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY environment variable not set")
        
        self.client = Anthropic(api_key=api_key)
        self.model = "claude-sonnet-4-20250514"
    
    def generate_interview_questions(
        self,
        company_name: str,
        position_title: str,
        interview_type: str,
        job_description: Optional[str] = None,
        user_background: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Generate relevant interview questions based on position and type
        
        Args:
            company_name: Target company
            position_title: Position being interviewed for
            interview_type: Type of interview
            job_description: Job description text
            user_background: User's background for personalization
            
        Returns:
            List of interview questions with guidance
        """
        
        prompt = self._build_questions_prompt(
            company_name=company_name,
            position_title=position_title,
            interview_type=interview_type,
            job_description=job_description,
            user_background=user_background
        )
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=3000,
                temperature=0.7,
                messages=[{"role": "user", "content": prompt}]
            )
            
            response_text = response.content[0].text
            
            # Parse the response
            questions = self._parse_questions_response(response_text)
            return questions
            
        except Exception as e:
            logger.error(f"Error generating questions: {str(e)}")
            raise Exception(f"Failed to generate interview questions: {str(e)}")
    
    def _build_questions_prompt(
        self,
        company_name: str,
        position_title: str,
        interview_type: str,
        job_description: Optional[str],
        user_background: Optional[Dict[str, Any]]
    ) -> str:
        """Build prompt for question generation"""
        
        interview_type_guidance = {
            "Phone Screen": "screening questions about background, interest, and basic fit",
            "Behavioral": "behavioral questions using the STAR method to assess past experiences",
            "Technical": "technical questions to assess coding, problem-solving, and domain knowledge",
            "Case Study": "business case questions requiring analytical and problem-solving skills",
            "Panel": "mixed questions from multiple interviewers covering various aspects",
            "Final Round": "strategic questions about long-term fit, culture, and decision-making"
        }
        
        type_desc = interview_type_guidance.get(interview_type, "general interview questions")
        
        job_desc_str = ""
        if job_description:
            job_desc_str = f"\n**Job Description:**\n{job_description[:800]}"
        
        background_str = ""
        if user_background:
            background_str = f"""
**Candidate Background:**
- Major: {user_background.get('major', 'N/A')}
- Academic Level: {user_background.get('academic_level', 'N/A')}
- Skills: {', '.join(user_background.get('skills', [])[:8])}
"""
        
        prompt = f"""You are an expert interview coach. Generate realistic interview questions for this scenario:

**Interview Details:**
- Company: {company_name}
- Position: {position_title}
- Interview Type: {interview_type}
{job_desc_str}
{background_str}

**Task:** Generate 10-12 {type_desc} that would be asked for this {interview_type} interview.

**Return in this JSON format:**
[
  {{
    "question": "The interview question",
    "category": "behavioral/technical/situational/general",
    "difficulty": "easy/medium/hard",
    "tip": "Brief tip on how to approach this question",
    "star_applicable": true/false
  }}
]

**Guidelines:**
- Make questions specific to the role and company
- Mix difficulty levels
- Include both common and unique questions
- Provide actionable tips
- Mark questions where STAR method applies

Generate the questions now in valid JSON format:"""
        
        return prompt
    
    def _parse_questions_response(self, response_text: str) -> List[Dict[str, Any]]:
        """Parse questions response into structured format"""
        
        try:
            # Extract JSON from response
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            elif "```" in response_text:
                json_start = response_text.find("```") + 3
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            else:
                json_text = response_text.strip()
            
            questions = json.loads(json_text)
            return questions if isinstance(questions, list) else []
            
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse questions JSON. Response: {response_text[:200]}")
            return []
    
    def evaluate_answer(
        self,
        question: str,
        answer: str,
        use_star: bool = False
    ) -> Dict[str, Any]:
        """
        Evaluate a practice interview answer
        
        Args:
            question: The interview question
            answer: Candidate's answer
            use_star: Whether to evaluate using STAR method
            
        Returns:
            Feedback and score
        """
        
        star_guidance = ""
        if use_star:
            star_guidance = """
**STAR Method Evaluation:**
- Situation: Did they set the context clearly?
- Task: Did they explain their responsibility?
- Action: Did they detail their specific actions?
- Result: Did they quantify the outcome?
"""
        
        prompt = f"""You are an expert interview coach. Evaluate this practice answer:

**Question:** {question}

**Candidate's Answer:** {answer}
{star_guidance}

**Provide evaluation in this JSON format:**
{{
  "score": 7,
  "rating": "good",
  "strengths": ["Strength 1", "Strength 2"],
  "improvements": ["Area 1", "Area 2"],
  "star_analysis": {{
    "situation": "feedback on situation",
    "task": "feedback on task",
    "action": "feedback on action",
    "result": "feedback on result"
  }},
  "suggested_revision": "Improved version of the answer"
}}

**Scoring:**
- 1-3: Needs significant improvement
- 4-6: Adequate but could be stronger
- 7-8: Good answer with minor improvements possible
- 9-10: Excellent answer

Be constructive and specific. Generate the evaluation now:"""
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=2000,
                temperature=0.5,
                messages=[{"role": "user", "content": prompt}]
            )
            
            response_text = response.content[0].text
            
            # Parse evaluation
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            else:
                json_text = response_text.strip()
            
            evaluation = json.loads(json_text)
            return evaluation
            
        except Exception as e:
            logger.error(f"Error evaluating answer: {str(e)}")
            return {
                "score": 5,
                "rating": "adequate",
                "strengths": ["Answer provided"],
                "improvements": ["Could not evaluate at this time"],
                "suggested_revision": answer
            }
    
    def generate_company_research(
        self,
        company_name: str,
        position_title: str
    ) -> Dict[str, Any]:
        """
        Generate company research brief for interview prep
        
        Args:
            company_name: Target company
            position_title: Position title
            
        Returns:
            Research brief with key information
        """
        
        prompt = f"""Create a comprehensive company research brief for interview preparation:

**Company:** {company_name}
**Position:** {position_title}

**Provide research in this JSON format:**
{{
  "company_overview": "Brief overview of the company",
  "mission_values": "Company mission and core values",
  "recent_news": ["Recent news item 1", "Recent news item 2"],
  "culture": "Company culture description",
  "products_services": ["Product/Service 1", "Product/Service 2"],
  "competitors": ["Competitor 1", "Competitor 2"],
  "interview_insights": "What this company looks for",
  "questions_to_ask": [
    "Thoughtful question 1",
    "Thoughtful question 2",
    "Thoughtful question 3"
  ]
}}

**Note:** Base this on general knowledge. Include realistic and helpful information.

Generate the research brief now in valid JSON:"""
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=2500,
                temperature=0.7,
                messages=[{"role": "user", "content": prompt}]
            )
            
            response_text = response.content[0].text
            
            # Parse research brief
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            else:
                json_text = response_text.strip()
            
            research = json.loads(json_text)
            return research
            
        except Exception as e:
            logger.error(f"Error generating company research: {str(e)}")
            return {
                "company_overview": f"Research {company_name} before your interview",
                "questions_to_ask": [
                    "What does success look like in this role?",
                    "How would you describe the team culture?",
                    "What are the biggest challenges facing the team?"
                ]
            }
    
    def generate_star_story(
        self,
        topic: str,
        user_experiences: List[str]
    ) -> str:
        """
        Help generate a STAR-format story from user's experiences
        
        Args:
            topic: Topic or skill to highlight (e.g., "leadership", "problem-solving")
            user_experiences: User's relevant experiences
            
        Returns:
            STAR-formatted story
        """
        
        experiences_str = "\n".join([f"- {exp}" for exp in user_experiences])
        
        prompt = f"""Help create a compelling STAR-format story for this topic:

**Topic/Skill:** {topic}

**Available Experiences:**
{experiences_str}

**Task:** Create a concise STAR-format story (150-200 words) that demonstrates {topic}.

**STAR Format:**
- Situation: Set the context (1-2 sentences)
- Task: Explain your responsibility (1 sentence)
- Action: Detail what YOU did (2-3 sentences)
- Result: Share the outcome with metrics (1-2 sentences)

**Guidelines:**
- Use first person ("I")
- Be specific with numbers/metrics
- Focus on your individual contribution
- Make it memorable
- Keep it concise

Write the STAR story now:"""
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1000,
                temperature=0.8,
                messages=[{"role": "user", "content": prompt}]
            )
            
            story = response.content[0].text.strip()
            return story
            
        except Exception as e:
            logger.error(f"Error generating STAR story: {str(e)}")
            return f"Consider using your experience to demonstrate {topic} in a STAR format."
    
    def generate_closing_questions(
        self,
        company_name: str,
        position_title: str,
        interview_stage: str = "first"
    ) -> List[str]:
        """
        Generate thoughtful questions for candidate to ask interviewer
        
        Args:
            company_name: Company name
            position_title: Position title
            interview_stage: Stage of interview (first, second, final)
            
        Returns:
            List of questions to ask
        """
        
        prompt = f"""Generate 5-7 thoughtful questions a candidate should ask at the end of their {interview_stage} interview:

**Company:** {company_name}
**Position:** {position_title}
**Interview Stage:** {interview_stage} interview

**Requirements:**
- Show genuine interest and research
- Avoid questions about salary/benefits (unless final interview)
- Focus on role, team, growth, and culture
- Mix tactical and strategic questions
- Make them specific to the role

Return as a JSON array of question strings:
["Question 1", "Question 2", ...]"""
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1000,
                temperature=0.7,
                messages=[{"role": "user", "content": prompt}]
            )
            
            response_text = response.content[0].text.strip()
            
            # Parse questions
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            elif "```" in response_text:
                json_start = response_text.find("```") + 3
                json_end = response_text.rfind("```")
                json_text = response_text[json_start:json_end].strip()
            else:
                json_text = response_text.strip()
            
            questions = json.loads(json_text)
            return questions if isinstance(questions, list) else []
            
        except Exception as e:
            logger.error(f"Error generating closing questions: {str(e)}")
            return [
                "What does success look like in this role during the first 90 days?",
                "How would you describe the team culture and collaboration style?",
                "What are the biggest challenges facing the team right now?"
            ]
