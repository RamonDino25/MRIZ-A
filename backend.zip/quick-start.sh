#!/bin/bash

# AI Career Coach - Quick Start Script
# This script sets up and runs the backend

echo "=========================================="
echo "🎓 AI Career Coach - Quick Start"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running in backend directory
if [ ! -f "requirements.txt" ]; then
    echo -e "${YELLOW}⚠️  Please run this script from the backend directory${NC}"
    echo "   cd backend && ./quick-start.sh"
    exit 1
fi

# Check Python version
echo "📌 Checking Python version..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is not installed${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d" " -f2 | cut -d"." -f1,2)
REQUIRED_VERSION="3.11"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo -e "${RED}❌ Python 3.11+ required, you have $PYTHON_VERSION${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Python $PYTHON_VERSION found${NC}"
echo ""

# Check if .env exists
if [ ! -f "../.env" ]; then
    echo "📝 Creating .env file from template..."
    cp ../.env.example ../.env
    echo -e "${YELLOW}⚠️  Please edit .env and add your ANTHROPIC_API_KEY${NC}"
    echo "   You can get one at: https://console.anthropic.com/"
    echo ""
    read -p "Press Enter after adding your API key to continue..."
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "🔨 Creating virtual environment..."
    python3 -m venv venv
    echo -e "${GREEN}✅ Virtual environment created${NC}"
else
    echo -e "${GREEN}✅ Virtual environment already exists${NC}"
fi
echo ""

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

# Initialize database
echo "🗄️  Initializing database..."
python3 << EOF
from models.database import init_db
init_db()
print("✅ Database initialized")
EOF
echo ""

# Check if ANTHROPIC_API_KEY is set
source ../.env
if [ -z "$ANTHROPIC_API_KEY" ] || [ "$ANTHROPIC_API_KEY" = "your_anthropic_api_key_here" ]; then
    echo -e "${YELLOW}⚠️  WARNING: ANTHROPIC_API_KEY not set in .env${NC}"
    echo "   AI features will not work without it!"
    echo ""
fi

# Start the server
echo "=========================================="
echo "🚀 Starting AI Career Coach Backend"
echo "=========================================="
echo ""
echo -e "${GREEN}✅ Server starting at http://localhost:8000${NC}"
echo -e "${GREEN}📚 API Documentation: http://localhost:8000/docs${NC}"
echo -e "${GREEN}💚 Health Check: http://localhost:8000/health${NC}"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Run the server
python3 main.py
