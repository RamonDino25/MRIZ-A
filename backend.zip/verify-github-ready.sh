#!/bin/bash

echo "============================================================"
echo "🔍 AI CAREER COACH BACKEND - GITHUB READY CHECK"
echo "============================================================"
echo ""

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Counter
total_checks=0
passed_checks=0

# Function to check file
check_file() {
    total_checks=$((total_checks + 1))
    if [ -f "$1" ]; then
        echo -e "  ${GREEN}✓${NC} $1"
        passed_checks=$((passed_checks + 1))
        return 0
    else
        echo -e "  ${RED}✗${NC} $1 ${RED}MISSING${NC}"
        return 1
    fi
}

# Check essential files
echo "📁 Checking Essential Files..."
check_file "main.py"
check_file "requirements.txt"
check_file "Dockerfile"
check_file "docker-compose.yml"
check_file ".env.example"
check_file ".gitignore"
check_file "README.md"
check_file "SECURITY.md"
check_file "GITHUB_SETUP.md"
check_file "quick-start.sh"
echo ""

# Check models
echo "📊 Checking Models..."
check_file "models/database.py"
check_file "models/schemas.py"
echo ""

# Check services
echo "🤖 Checking AI Services..."
check_file "services/ai_resume_service.py"
check_file "services/ai_cover_letter_service.py"
check_file "services/ai_interview_service.py"
echo ""

# Check for sensitive data
echo "🔒 Checking for Sensitive Data..."
total_checks=$((total_checks + 1))
# Exclude documentation files and only check code files
if grep -r "sk-ant-[a-zA-Z0-9]" --include="*.py" . > /dev/null 2>&1; then
    echo -e "  ${RED}✗${NC} Found hardcoded API keys in Python files! ${RED}REMOVE BEFORE UPLOAD${NC}"
else
    echo -e "  ${GREEN}✓${NC} No hardcoded API keys in code"
    passed_checks=$((passed_checks + 1))
fi

total_checks=$((total_checks + 1))
if [ -f ".env" ]; then
    echo -e "  ${YELLOW}⚠${NC}  .env file present (will be ignored by .gitignore)"
    passed_checks=$((passed_checks + 1))
else
    echo -e "  ${GREEN}✓${NC} No .env file (good - won't be committed)"
    passed_checks=$((passed_checks + 1))
fi
echo ""

# Check Python syntax
echo "🐍 Checking Python Syntax..."
total_checks=$((total_checks + 1))
if python3 -m py_compile main.py models/*.py services/*.py 2>/dev/null; then
    echo -e "  ${GREEN}✓${NC} All Python files compile successfully"
    passed_checks=$((passed_checks + 1))
else
    echo -e "  ${RED}✗${NC} Python syntax errors found"
fi
echo ""

# Count files
echo "📊 File Statistics..."
python_files=$(find . -name "*.py" -not -path "./__pycache__/*" | wc -l)
total_lines=$(find . -name "*.py" -not -path "./__pycache__/*" -exec wc -l {} + 2>/dev/null | tail -1 | awk '{print $1}')
echo "  • Python files: $python_files"
echo "  • Total lines of code: $total_lines"
echo "  • Documentation files: 4 (README, SECURITY, GITHUB_SETUP, CHANGELOG)"
echo ""

# Final summary
echo "============================================================"
echo "📋 SUMMARY"
echo "============================================================"
echo ""
echo "Checks passed: $passed_checks / $total_checks"
echo ""

if [ $passed_checks -eq $total_checks ]; then
    echo -e "${GREEN}✅ ALL CHECKS PASSED!${NC}"
    echo ""
    echo "🚀 Your backend is ready for GitHub!"
    echo ""
    echo "Next steps:"
    echo "  1. Create repository at: https://github.com/new"
    echo "  2. Follow GITHUB_SETUP.md for upload instructions"
    echo "  3. Repository name: ai-career-coach-backend"
    echo ""
    echo "Quick command:"
    echo "  git init"
    echo "  git add ."
    echo "  git commit -m 'Initial commit - Production ready backend'"
    echo "  git remote add origin https://github.com/YOUR_USERNAME/ai-career-coach-backend.git"
    echo "  git push -u origin main"
    echo ""
    exit 0
else
    echo -e "${RED}❌ SOME CHECKS FAILED${NC}"
    echo ""
    echo "Please fix the issues above before uploading to GitHub."
    echo ""
    exit 1
fi
